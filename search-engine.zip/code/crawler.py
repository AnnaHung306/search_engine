"""crawler.py — topic-focused crawler for the Kali/Nmap/Metasploit pentest search engine.

Obeys robots.txt, keeps >= 2s between requests to the same host, uses an
identifiable User-Agent, sets a request timeout, caps total attempts, backs off
on rate-limit responses, normalizes URLs, stays inside the host+path allowlist
(including after redirects), and logs failures and skipped URLs.

Output:
    data/pages.json   list of {url, title, text, fetch_time}
    data/crawl_log.jsonl  one record per attempt (fetched / skipped / failed)
    data/crawl_summary.json  aggregate statistics
"""
import hashlib
import json
import sys
import time
import os
from collections import defaultdict, deque
from urllib.parse import urljoin, urlsplit, urlunsplit
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup

import config

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(DATA_DIR, exist_ok=True)
PAGES_PATH = os.path.join(DATA_DIR, "pages.json")
LOG_PATH = os.path.join(DATA_DIR, "crawl_log.jsonl")
SUMMARY_PATH = os.path.join(DATA_DIR, "crawl_summary.json")
STATE_PATH = os.path.join(DATA_DIR, "crawl_state.json")   # checkpoint for --resume

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": config.USER_AGENT})


# ---------------------------------------------------------------- URL helpers
def normalize(url, base=None):
    """Resolve relative URLs and drop #fragments. Query strings are KEPT
    (the spec warns query params may identify different pages)."""
    if base:
        url = urljoin(base, url)
    parts = urlsplit(url)
    scheme = parts.scheme.lower()
    netloc = parts.netloc.lower()
    # strip default ports
    if netloc.endswith(":80"):
        netloc = netloc[:-3]
    if netloc.endswith(":443"):
        netloc = netloc[:-4]
    return urlunsplit((scheme, netloc, parts.path, parts.query, ""))  # no fragment


def in_scope(url):
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https"):
        return False
    host = parts.netloc.lower()
    if host not in config.ALLOWED_HOSTS:
        return False
    allowed = config.ALLOWED_PATH_PREFIXES.get(host, ())
    if allowed and not parts.path.startswith(allowed):
        return False
    excluded = config.EXCLUDED_PATH_PREFIXES.get(host, ())
    if excluded and parts.path.startswith(excluded):
        return False
    return True


# ---------------------------------------------------------------- robots
_robots = {}


def robots_for(host):
    if host not in _robots:
        # fetch robots.txt with OUR User-Agent (urllib's default UA gets 403 on some sites)
        rp = RobotFileParser()
        try:
            r = SESSION.get(f"https://{host}/robots.txt", timeout=config.TIMEOUT)
            if r.status_code == 200:
                rp.parse(r.text.splitlines())
            elif r.status_code in (401, 403):
                rp.disallow_all = True      # access restricted -> do not crawl
            else:
                rp.allow_all = True         # no robots.txt -> allowed
        except requests.RequestException:
            rp.allow_all = True
        _robots[host] = rp
    return _robots[host]


def robots_allows(url):
    host = urlsplit(url).netloc.lower()
    rp = robots_for(host)
    if rp is None:
        return True
    return rp.can_fetch(config.USER_AGENT, url)


# ---------------------------------------------------------------- text extract
MAIN_SELECTORS = ["main", "article", "[role=main]", "#main-content",
                  ".main-content", "#content", ".content", "#main"]


def extract(html):
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.get_text(strip=True) if soup.title else ""
    # v7: collect links from the WHOLE page before stripping <nav>/<aside>.
    # Some doc sites (mitmproxy, Metasploit) only link their chapters from the
    # sidebar; taking links from <main> alone found 3 mitmproxy pages.
    # The scope allowlist still decides which links are followed.
    links = [a["href"] for a in soup.find_all("a", href=True)]
    # remove non-content tags
    for tag in soup(["script", "style", "noscript", "nav", "header",
                     "footer", "form", "aside"]):
        tag.decompose()
    node = None
    for sel in MAIN_SELECTORS:
        node = soup.select_one(sel)
        if node:
            break
    if node is None:
        node = soup.body or soup
    text = node.get_text(" ", strip=True)
    text = " ".join(text.split())
    return title, text, links


# ---------------------------------------------------------------- crawl loop
def crawl():
    # one queue per host, served round-robin so the 2s per-host delays overlap
    frontiers = defaultdict(deque)
    seen = set()
    for s in config.SEED_URLS:
        n = normalize(s)
        if n not in seen:
            seen.add(n)
            frontiers[urlsplit(n).netloc.lower()].append(n)
    stored = set()          # final URLs saved (after redirects)
    hashes = set()          # exact-duplicate text check

    pages = []
    last_hit = {}            # host -> last request monotonic time
    per_host_valid = defaultdict(int)
    attempts = 0
    stats = defaultdict(int)

    resume = "--resume" in sys.argv and os.path.exists(STATE_PATH)
    if resume:
        with open(STATE_PATH, encoding="utf-8") as f:
            st = json.load(f)
        frontiers = defaultdict(deque, {h: deque(q) for h, q in st["frontiers"].items()})
        seen, stored, hashes = set(st["seen"]), set(st["stored"]), set(st["hashes"])
        pages, attempts = st["pages"], st["attempts"]
        per_host_valid.update(st["per_host_valid"]); stats.update(st["stats"])
        print(f"Resumed: {len(pages)} pages, {attempts} attempts", flush=True)
    log_f = open(LOG_PATH, "a" if resume else "w", encoding="utf-8")

    def checkpoint():
        tmp = STATE_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"frontiers": {h: list(q) for h, q in frontiers.items()},
                       "seen": list(seen), "stored": list(stored), "hashes": list(hashes),
                       "pages": pages, "attempts": attempts,
                       "per_host_valid": dict(per_host_valid), "stats": dict(stats)}, f)
        os.replace(tmp, STATE_PATH)
        log_f.flush()

    def log(record):
        log_f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def host_delay(h):
        rp = robots_for(h)
        cd = rp.crawl_delay(config.USER_AGENT) if rp else None
        return max(config.DELAY_PER_HOST, float(cd or 0))  # honor longer site delay

    def queued():
        return sum(len(q) for q in frontiers.values())

    while queued() and len(pages) < config.MAX_VALID_PAGES and attempts < config.MAX_ATTEMPTS:
        # pick the non-empty host that becomes ready soonest
        host = min((h for h in frontiers if frontiers[h]),
                   key=lambda h: last_hit.get(h, 0) + host_delay(h))
        url = frontiers[host].popleft()

        if per_host_valid[host] >= config.MAX_PAGES_PER_HOST.get(host, config.MAX_VALID_PAGES):
            stats["skipped_host_cap"] += 1
            log({"url": url, "status": "skipped", "reason": "host_cap"})
            continue
        if not robots_allows(url):
            stats["skipped_robots"] += 1
            log({"url": url, "status": "skipped", "reason": "robots"})
            continue

        # per-host >= 2s spacing
        wait = host_delay(host) - (time.monotonic() - last_hit.get(host, 0))
        if wait > 0:
            time.sleep(wait)

        attempts += 1
        try:
            resp = SESSION.get(url, timeout=config.TIMEOUT, allow_redirects=True)
            last_hit[host] = time.monotonic()
        except requests.RequestException as e:
            last_hit[host] = time.monotonic()
            stats["failed_request"] += 1
            log({"url": url, "status": "failed", "reason": type(e).__name__})
            continue

        # rate limited -> back off, requeue once, do not hammer
        if resp.status_code == 429:
            stats["rate_limited"] += 1
            retry = int(resp.headers.get("Retry-After", 30))
            log({"url": url, "status": "backoff", "retry_after": retry})
            time.sleep(min(retry, 60))
            last_hit[host] = time.monotonic()
            continue
        if resp.status_code != 200:
            stats["failed_status"] += 1
            log({"url": url, "status": "failed", "code": resp.status_code})
            continue

        ctype = resp.headers.get("Content-Type", "")
        if "html" not in ctype.lower():
            stats["skipped_nonhtml"] += 1
            log({"url": url, "status": "skipped", "reason": "nonhtml", "ctype": ctype})
            continue

        # scope check AFTER redirects
        final_url = normalize(str(resp.url))
        if not in_scope(final_url):
            stats["skipped_redirect_out"] += 1
            log({"url": url, "status": "skipped", "reason": "redirect_out_of_scope",
                 "final": final_url})
            continue

        # v7: a page served as text/html with no charset is decoded as ISO-8859-1
        # by requests, which turned Frida's "•" into "â¢". Use the detected one.
        if "charset" not in ctype.lower():
            resp.encoding = resp.apparent_encoding or "utf-8"
        title, text, links = extract(resp.text)

        # enqueue in-scope links
        for href in links:
            try:
                nurl = normalize(href, base=final_url)
            except Exception:
                continue
            if nurl not in seen and in_scope(nurl):
                seen.add(nurl)
                frontiers[urlsplit(nurl).netloc.lower()].append(nurl)

        if final_url in stored:
            stats["skipped_duplicate_url"] += 1
            log({"url": url, "status": "skipped", "reason": "duplicate_after_redirect",
                 "final": final_url})
            continue
        h = hashlib.md5(text.encode("utf-8")).hexdigest()
        if h in hashes:
            stats["skipped_duplicate_text"] += 1
            log({"url": final_url, "status": "skipped", "reason": "duplicate_text"})
            continue
        if len(text) < config.MIN_TEXT_CHARS:
            stats["skipped_thin"] += 1
            log({"url": final_url, "status": "skipped", "reason": "thin_text",
                 "chars": len(text)})
            continue

        page = {
            "url": final_url,
            "title": title,
            "text": text,
            "fetch_time": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }
        pages.append(page)
        stored.add(final_url)
        hashes.add(h)
        per_host_valid[host] += 1
        stats["valid"] += 1
        log({"url": final_url, "status": "fetched", "chars": len(text),
             "title": title})
        if stats["valid"] % 25 == 0:
            checkpoint()
            print(f"[{stats['valid']}] valid, {attempts} attempts, "
                  f"{queued()} queued", flush=True)

    checkpoint()
    log_f.close()
    with open(PAGES_PATH, "w", encoding="utf-8") as f:
        json.dump(pages, f, ensure_ascii=False, indent=1)

    failed = stats.get("failed_request", 0) + stats.get("failed_status", 0)
    summary = {
        "attempts": attempts,          # HTTP requests actually sent, incl. failures
        "failed": failed,              # network errors + non-200 responses
        "valid_pages": len(pages),
        "hosts": {h: per_host_valid[h] for h in per_host_valid},
        "avg_text_chars": round(sum(len(p["text"]) for p in pages) / len(pages), 1) if pages else 0,
        "skipped_and_failed": dict(stats),
        "frontier_left": queued(),
    }
    with open(SUMMARY_PATH, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print("DONE", json.dumps(summary, ensure_ascii=False))
    return summary


if __name__ == "__main__":
    crawl()
